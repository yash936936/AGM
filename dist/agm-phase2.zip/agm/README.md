# AGM Phase 2

Adaptive Graph Memory (AGM) is a model-agnostic memory store for AI agents. Phase 1 provides an event-sourced SQLite core; Phase 2 adds entity-aware graph retrieval, alias resolution, provisional confidence/trust ranking, bounded expansion, contested writes, and abstention.

## Requirements

Python 3.11 or newer, SQLite with FTS5, `pydantic>=2`, and `numpy`. Tests use `pytest`.

## Install

```bash
python -m venv .venv
source .venv/bin/activate        # Windows Git Bash: source .venv/Scripts/activate
python -m pip install -e ".[dev]"
```

## Test

```bash
python -m pytest -q
```

## Demo, rebuild, and package

```bash
python -m agm demo
python -m agm rebuild --db ./demo.db
python scripts/pack.py
```

`retrieve(..., expand=False)` keeps the flat Phase 1 baseline available. The default `expand=True` path uses bounded graph expansion, confidence/trust/recency ranking and a one-time sufficiency widening before abstention. Retrieved memory is always labeled as untrusted data, not instructions.

**Scoring status:** Confidence and rank coefficients from decision D-008 are provisional placeholders, not calibrated probabilities or evidence that graph retrieval improves accuracy. Phase 2 does not add REST/MCP interfaces, authentication, redaction, quarantine, lifecycle decay, or handoff. Those remain later-phase work.
